# Dangeo Mystic

1. `npm install`
2. `npm run dev`
3. Suba para GitHub e conecte ao Railway
